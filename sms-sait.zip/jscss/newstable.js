//$(window).load(function() {
//
//});
$(document).ready(function() {
    ajaxNews();    
    $("#news").on('click', '.nov', function (e) { ajaxNews(); });
});

function ajaxNews() {
    $.ajax({  
        type: "GET",
        url: "/articles/ajax.news.html", 
        dataType: "json", 
        cache: false,  
        dataFilter: function (response, type) {
            var hash = window.location.hash; 
            var data = $.parseJSON(response); 
            
            if (hash != '') {
                var news_id = hash.substring(2);
                var moveblock = $("h2").clone();
                $("h2").remove();
                $("#news").after(moveblock);
                var oot = new Object();
                var tempArray = new Array();
                $.each( data.list, function( key, val ) {
                    if (val[4] == news_id) {
                        tempArray.push(val);
                        oot.list = tempArray;
                        $('title').text(tempArray[0][1]);
                    }
                });
            } else oot = data;

            return JSON.stringify(oot);
        },
        success: function(news){ 
            $("#news").empty();
            $.each( news.list, function( key, val ) {
                $(formatNews(key,val)).appendTo( $("#news") );
            });

        }  
    }); 
}

function formatNews(key,nov) {
    var eo = (key % 2 == 0) ? "even" : "odd";
    var out = 
    "<tr class='"+eo+"'>" +
        "<td class=''><div>" +
            "<div class='flag'>"+nov[0]+"</div>" +
            "<div class='newstitle'>" +
                "<a href='"+nov[3]+"' data-nov='"+nov[4]+"' class='nov'>" + nov[1] + "&nbsp;<img src='/images/lnk.png'></a>" +
            "</div>" +
            "<div class='clear'><br></div>" +
            nov[2] +
        "</div></td>" +
    "</tr>";
    return out;
}
