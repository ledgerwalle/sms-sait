$(document).ready(function() {
    $(".m-button").click(function(e) {
        e.preventDefault();
        $(".mobile-menu").toggleClass("show-menu");
    });
    $("#gt_button").click(function() {
        
        $.getScript( "//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit", 
            function( data, textStatus, jqxhr ) {$("#gt_button").remove();}

        );
    });
})

function showhits() {
    xhttp=new XMLHttpRequest();
    xhttp.open('GET','/ajaxdata/hits.json',true);
    xhttp.send();
    xhttp.onreadystatechange=function()  {
        if (xhttp.readyState==4)      {
            var stats=JSON.parse(xhttp.responseText); 
            document.getElementById('users').innerHTML      = stats.users;
        }
    }
}

function prices() {
        $.ajax({
            method: "GET",
            url: "ajaxdata/services.json",
            dataType: "json",
            cache: false
            })
            .done(function(msg) {
                var pricelist = $(document.createElement("div")).addClass("list_context").prop("id", "pricelist");
                var countries = ['ru','ua','kz','gb','pl','de','fr','md'];

                $.each(msg, function(index, item) {

                    var list_row  = $(document.createElement("div")).addClass("list_row"); 

                    list_row.append(
                        $(document.createElement("div")).addClass("cell_list_row w1 fl_l")
                            .append($(document.createElement("div")).addClass("serv")
                                .css("background-size", "20px")
                                .css("background-image", "url(/images/services/svg/"+item.slug+".svg)")
                                .html(item.description)
                            ) 
                    );
                    $.each(item, function(cntry, price) {


                        if (countries.indexOf(cntry) != -1) list_row.append(
                            $(document.createElement("div")).addClass("cell_list_row w2 texc fl_l")
                                .append($(document.createElement("span")).html(price)) 
                        );
                    })
                    list_row.append($(document.createElement("br")).addClass("clear"));
                    pricelist.append(list_row);
                })

                console.log(pricelist);
                $(document.getElementById("pricelist")).replaceWith(pricelist);

            });
}

function shownews() {
    lastnews=new XMLHttpRequest();
    lastnews.open('GET','/articles/ajax.news.html',true);
    lastnews.send();
    lastnews.onreadystatechange=function() {
        if (lastnews.readyState==4) {
            var newsli=JSON.parse(lastnews.responseText);
            var shownews = document.getElementById("boxnews");
            var newslines = '';
            k=0; 
            while (k < 9) {
                ntitle = newsli.list[k];
                newslines += "<li><a href='"+ntitle[3]+"'>"+ntitle[0]+": "+ntitle[1].substr(0, 26)+"</a></li>";
                k++;
            }
            shownews.innerHTML = newslines;
        }
    }
}

function googleTranslateElementInit() {
    new google.translate.TranslateElement(
        {pageLanguage: 'ru', includedLanguages: 'de,en,zh-TW,ru', 
            layout: google.translate.TranslateElement.InlineLayout.SIMPLE, autoDisplay: false
        },
        'google_translate_element'
    );
}


(function() {
    var wf = document.createElement('link');
    wf.href = '/jscss/fonts/opensans/open-sans.css';
    wf.type = 'text/css';
    wf.rel = 'stylesheet';
    wf.async = 'true';
    var s = document.getElementsByTagName('link')[0];
    s.parentNode.insertBefore(wf, s);
})();