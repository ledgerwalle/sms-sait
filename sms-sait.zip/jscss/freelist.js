$(document).ready(function() {
    var hash = window.location.hash;
    if (hash) getFreeMessageList(hash);

    $("#FreePhoneList").on('click', '.freePhone', function (e) { getFreeMessageList(e.target.hash); });
});

function getFreePhoneList() {
    $("#FreePhoneList").empty();

    country = $("#free-num-country-id").val();
    $.ajax({  
        type: "GET",
        url: "https://api.Virtu-SmS/getFreePhoneList.php?apikey=getFreePhoneList&country="+country, 
        dataType: "json", 
        cache: false,  
        success: function(response){ 
            $.each( response.items, function( key, val ) {
                
            }); 
        }  
    }); 
}

function getFreeMessageList(hash) {
    $("#FreePhoneList").empty();
    $.ajax({  
        type: "GET",
        url: "https://api.Virtu-SmS/getFreeMessageList.php?apikey=getFreePhoneList&number="+hash.substring(1), 
        dataType: "json", 
        cache: false,  
        success: function(response){ 
            $("#FreePhoneList").empty();
            $("<div class='free-num-header'>" +
                "<img src='/images/old-phone.png' alt='phone' class='free-num-item-img sprite-country'>" +
                "<div class='free-num-header-number'>"+hash.substring(1)+"</div>" + 
                "<div  class='free-num-header-status'><a href='' class='freePhone'>Список номеров</a></div>" +
                "<img src='/images/svg/update.svg' alt='update' height='16' class='free-num-header-update-icon'>" +
                "<a href='#"+hash.substring(1)+"' class='freePhone'>Обновить</a>" +
            "</div>").appendTo( $("#FreePhoneList") );

            $("<ul class='free-num-list'>").appendTo( $("#FreePhoneList") );
            $.each( response.items, function( key, val ) {
                $(formathtmlmessages(key, val)).appendTo( $("#FreePhoneList") );
            }); 
            $("</ul>").appendTo( $("#FreePhoneList") );
        }  
    }); 
}
function formathtmlmessages(key, val) {
    var eo = (key % 2 == 0) ? "even" : "odd";
    var out = 
        "<li class='free-num-item'>" +
            "<div class='free-num-item-body'>" +
                "<div class='free-num-item-body-top'>" +
                    "<div class='free-num-item-title'>" + val.sender + "</div>" +
                    "<div class='free-num-item-date'>" + relative_time(val.date) + "</div>" +
                "</div>" +
                "<div class='free-num-item-body-bottom'>" +
                    "<div class='free-num-item-text'> " + val.text + " </div>" +
                "</div>" +
            "</div>" +
        "</li>";
    return out;
}

function relative_time(date_str) {
    if (!date_str) {return;}
    date_str = $.trim(date_str);
    date_str = date_str.replace(/([\+\-]\d\d)\:?(\d\d)/," $1$2"); // +08:00 -> +0800
    var parsed_date = new Date(date_str);
    var relative_to = (arguments.length > 1) ? arguments[1] : new Date();
    var delta = parseInt((relative_to.getTime()-parsed_date)/1000);
    delta=(delta<2)?2:delta;
    var r = '';

    if (delta < 60) {
        r = delta + ' seconds ago';
    } else if(delta < 120) {
        r = 'a minute ago';
    } else if(delta < (45*60)) {
        r = (parseInt(delta / 60, 10)).toString() + ' minutes ago';
    } else if(delta < (2*60*60)) {
        r = 'an hour ago';
    } else if(delta < (24*60*60)) {
        r = '' + (parseInt(delta / 3600, 10)).toString() + ' hours ago';
    } else if(delta < (48*60*60)) {
        r = 'a day ago';
    } else {
        r = (parseInt(delta / 86400, 10)).toString() + ' days ago';
    }
    return 'about ' + r;
};